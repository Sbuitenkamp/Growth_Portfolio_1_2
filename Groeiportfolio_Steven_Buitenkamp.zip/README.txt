Om dit portfolio te bekijken open het bestand index.html in een van de volgende browsers:
    - Google Chrome
    - Firefox
    - Safari
    - Microsoft Edge
    - Opera

Daarna is het hele portfolio te navigeren via de browser.

Er zijn PDF varianten gemaakt voor administratieve doeleinden, maar deze hebben weinig tot geen opmaak. De site is bedoelt voor de beoordeling.